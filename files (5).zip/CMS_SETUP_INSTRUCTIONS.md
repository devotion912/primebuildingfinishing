# 🎉 Netlify CMS Setup Instructions

## Prime Building Finishing - Product Management System

---

## **STEP 1: Upload All Files to Netlify**

You now have **4 NEW files** to upload:

1. ✅ **index.html** (updated with authentication)
2. ✅ **admin.html** (NEW - CMS dashboard)
3. ✅ **netlify.toml** (NEW - CMS configuration)
4. ✅ **pbf-logo.png** (existing logo)
5. ✅ **turkey-door.jpg** (existing door image)

### Upload Instructions:
1. Go to **Netlify** dashboard
2. Click your site → **"Deploys"**
3. Click **"Upload files"** or **"Deploy manually"**
4. **Drag and drop ALL 5 FILES**
5. Wait 30-60 seconds ✅
6. Your site will update

---

## **STEP 2: Enable Identity & Git Gateway in Netlify**

### Enable Netlify Identity:

1. Go to **Netlify Dashboard** → Click your site
2. Go to **"Site settings"** (top right)
3. Click **"Identity"** in left sidebar
4. Click **"Enable Identity"**
5. Click **"Invite users"** button

### Add User 1 - Business Owner:
1. Click **"Invite users"**
2. Email: `ighosotub@gmail.com`
3. Click **"Send"**
4. Bright Ighosotu will receive email with login link
5. They set password to: `mayor008` (or what they prefer)

### Add User 2 - You (Developer):
1. Click **"Invite users"** again
2. Email: `devotion912@gmail.com`
3. Click **"Send"**
4. You receive email with login link
5. Set your own password

---

## **STEP 3: Enable Git Gateway**

Still in **"Identity"** settings:

1. Scroll down to **"Services"**
2. Click **"Git Gateway"**
3. Click **"Enable Git Gateway"**
4. Choose branch: `main` (or default)
5. Click **"Save"**

✅ This allows CMS to save changes to your site!

---

## **STEP 4: Refresh Your Site**

1. Open browser
2. Go to `primebuildingfinishing.com`
3. Press **F5** to refresh
4. Wait 10 seconds

---

## **STEP 5: Access the CMS Dashboard**

### For Business Owner (Bright):
1. Go to: `primebuildingfinishing.com/admin`
2. Login with email: `ighosotub@gmail.com`
3. Password: `mayor008`
4. ✅ See "Products" and "Site Settings" options

### For You (Developer):
1. Go to: `primebuildingfinishing.com/admin`
2. Login with email: `devotion912@gmail.com`
3. Password: (your password)
4. ✅ See "Products" and "Site Settings" options

---

## **STEP 6: How to Add/Edit Products**

### Add New Product:
1. Login to `/admin`
2. Click **"🚪 Products"** (left sidebar)
3. Click **"New Product"** button
4. Fill in:
   - **Product Name:** e.g., "Security Steel Door"
   - **Product ID:** e.g., "p13" (unique)
   - **Price:** e.g., 580000
   - **Category:** Security, Entrance, Interior, or Hardware
   - **Description:** Optional
   - **Door Type:** Optional (for illustration)
5. Click **"Publish"**
6. ✅ Website updates automatically!

### Edit Existing Product:
1. Login to `/admin`
2. Click **"🚪 Products"**
3. Click any product to edit
4. Change price, name, description
5. Click **"Publish"**
6. ✅ Changes live immediately!

### Delete Product:
1. Click product
2. Click **"Delete"** button
3. Confirm
4. ✅ Product removed from website

---

## **STEP 7: Update Site Settings**

### Change Business Contact Info:
1. Login to `/admin`
2. Click **"⚙️ Site Settings"** (left sidebar)
3. Click **"Business Settings"**
4. Update:
   - Business Name
   - Phone Number
   - WhatsApp Number
   - Email
   - Tagline
5. Click **"Publish"**
6. ✅ Website updates!

---

## **USER ACCOUNTS:**

### Account 1 - Business Owner:
```
Name: Bright Ighosotu
Email: ighosotub@gmail.com
Password: mayor008
Role: Full Access (can add/edit/delete products)
```

### Account 2 - Developer/You:
```
Email: devotion912@gmail.com
Password: (your password)
Role: Full Access (can manage everything)
```

---

## **TROUBLESHOOTING:**

### "Identity not found" error:
- Make sure **"Enable Identity"** is ON in Netlify
- Make sure **"Git Gateway"** is ON in Netlify
- Wait 5 minutes for settings to propagate

### Products not showing on website:
- Make sure you clicked **"Publish"** in CMS
- Refresh website (F5)
- Wait 30 seconds

### Can't login to CMS:
- Check email for Netlify Identity invite
- Click the link in the email
- Set your password
- Try again

---

## **NEXT STEPS:**

1. ✅ Upload all 5 files to Netlify
2. ✅ Enable Identity in Netlify
3. ✅ Invite both users
4. ✅ Enable Git Gateway
5. ✅ Go to `/admin` and login
6. ✅ Add your first product!

---

## **YOU'RE ALL SET!** 🚀

Both you and Bright can now:
- ✅ Add unlimited products
- ✅ Edit prices anytime
- ✅ Update descriptions
- ✅ Delete products
- ✅ Update contact info
- ✅ Website updates automatically!

**No coding needed!** 🎉
